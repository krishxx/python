# Steps to run forum_scraper

# Create new virtual environment
cd /opt/python/venv/
virtualenv generic

# Activate virtual environment
source /opt/python/venv/generic/bin/activate

# Install requirement from requirements.txt file
cd ~/path/to/generic
pip install -r requirements.txt

# To initialize DB will create a database.
# before running this commend please set sql details in "settings.py" file.
# Run script
# Result will be logged to .log file in the current working dir.
python generic_forum_scraper.py Forum_1
# Work In Progress
python generic_forum_scraper.py Forum_2
python generic_forum_scraper.py Forum_3
