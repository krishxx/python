# appending the path to find libraries
sys.path.append(os.path.dirname(os.path.realpath(__name__)))
sys.path.append(os.path.dirname(os.path.dirname(os.path.realpath(__name__))))

# import all required modules
from generic import *

parser = argparse.ArgumentParser()
parser.add_argument("forum", help="Give forum value from setting.py file like Forum_1",
                    type=str)
parser.add_argument("-r", "--rawhtml", help="Store raw html pages",
                    action="store_true")
args = parser.parse_args()

if args.forum:
    forum = args.forum

# import required type module from core directory
t_module = importlib.import_module ('core.'+yaml_obj[forum]['TYPE'])

# initialize db
generic_initialize_db.initialize_db (forum, args.rawhtml)

PROJECT_ROOT = os.path.dirname(os.path.realpath(__name__))
DB_URL = 'mysql://' + yaml_obj[forum]['DB_USERNAME'] + ':' + yaml_obj[forum]['DB_PASSWORD'] + '@' + yaml_obj[forum]['HOST'] + '/' + yaml_obj[forum]['DB_NAME'] + '?charset=utf8'
baseurl = yaml_obj[forum]['WEB_URL']

# Define Queue
q = Queue(2 * yaml_obj[forum]['NUM_THREADS'])
threadLock = threading.Lock()


# Log file info
logfilename = PROJECT_ROOT + '/' + yaml_obj[forum]['PROJECT'] + '_' + datetime.now().strftime("%Y_%m_%d") + '.log'
logging.basicConfig(
    name=yaml_obj[forum]['PROJECT'],
    level=logging.INFO,
    format='%(asctime)s %(message)s',
    datefmt='%Y-%m-%d %H:%M:%S',
    filename=logfilename
    )

engine = create_engine(DB_URL)
failed_thread_list = list()
failed_post_list = list()



def parse_forum():
    """ List all forum urls """

    try:
        if yaml_obj.get(forum).get('Meta').get('Forum').get('extention'):
            soup = t_module.get_parse_content(baseurl + yaml_obj.get(forum).get('Meta').get('Forum').get('extention'))
        else:
            soup = t_module.get_parse_content(baseurl)
        soup = t_module.get_parse_content(baseurl)
        forum_urls = t_module.get_forum_urls (soup)
        print forum_urls
        for forum_url in forum_urls:
            # parse_thread(forum_url)
            q.put(forum_url)

    except Exception as e:
        if yaml_obj.get(forum).get('Meta').get('Forum').get('extention'):
            print '*************** Main Url exception :\t' + str(baseurl + yaml_obj.get(forum).get('Meta').get('Forum').get('extention'))
        else:
            print '*************** Main Url exception :\t' + str(baseurl)
        print "++++++++++++++ Main Page Exception +++++++++++++++++++"
        print e
        pass


def parse_thread(f_url):
    """ 
        List all threads by forum url and
        store thread information
    """
    try:
        soup = t_module.get_parse_content(f_url)
        forum_url = f_url
        r_url = yaml_obj.get(forum).get('Meta').get('Forum').get('url')
        f_id = int(re.search(re.escape(r_url).replace('\%s', '([\d]+)'), f_url, re.I).group(1))

        if soup:
            forum_uuid = yaml_obj[forum]['FORUM_UUID']
            # Get all thread list pages by pagination
            total_pages = t_module.get_total_page_count (soup, f_url)
            print "total Forum Pages", total_pages
            for page in range(1, total_pages + 1):
                # Initial Session
                _session = sessionmaker()
                _session.configure(bind=engine)

                # Form a forum URL by pagination
                forum_url = str(baseurl + yaml_obj.get(forum).get('Meta').get('Forum').get('page_url'))  % (f_id, page)
                print forum_url
                logging.info('------------------->Forum URL: ' + forum_url)
                soup = t_module.get_parse_content(forum_url)
                if not soup:
                    failed_thread_list.append(forum_url)
                    continue
                rows = t_module.get_thread_rows (soup, f_id)
                for row in rows:
                    thread_info = t_module.get_thread_info (row, baseurl)
                    if thread_info:
                        thread_date = thread_info['thread_date']
                        thread_name = thread_info['thread_name']
                        thread_url = thread_info['thread_url']
                    else:
                        continue
                    # create session
                    session = _session()

                    # Check for exisiting entry in the DB.
                    # If entry is not present then add it to DB.
                    is_thread_details_exist = session.query(
                        Topic
                    ).filter_by(url=thread_url, third_party_id=thread_id).first()

                    if not is_thread_details_exist:
                        thread_uuid = str(uuid.uuid4())
                        logging.info('--------->Forum URL: \t' + str(forum_url))
                        logging.info('--------->Forum UUID \t' + str(forum_uuid))
                        logging.info('--------->Thread Name \t' + str(thread_name))
                        logging.info('--------->Thread UUID \t' + str(thread_uuid))
                        logging.info('--------->Thread Date \t' + str(thread_date))

                        print('--------->Forum URL', str(forum_url))
                        print('--------->Thread Name', str(thread_name))
                        print('--------->Thread Date', str(thread_date))

                        # Add data to database
                        topic = Topic(uuid=thread_uuid, forum_uuid=forum_uuid,
                                      third_party_id=thread_id, name=thread_name,
                                      created_at=thread_date, url=thread_url)

                        # Save object to the database.
                        session.add(topic)
                        try:
                            # Commit the changes.
                            session.commit()
                        except IntegrityError:
                            # Duplicate key error, we simply ignore it and rollback and newly added object.
                            session.rollback()
                            continue
                    else:
                        thread_uuid = is_thread_details_exist.uuid

                    # Session Close
                    session.close()

                    # Get all Threads by each forum
                    parse_post(thread_url, thread_id, thread_uuid)

        else:
            failed_thread_list.append(forum_url)
            print "****************************************** Forum Page Not Found ***************************"
    except Exception as e:
        print '************** Forum URL exception :\t' + str(forum_url)
        failed_thread_list.append(forum_url)
        print "************** Forum Exception *****************"
        print e
        pass


def parse_post(t_url, t_id, thread_uuid):
    """ List all posts by thread url and
        store post information
    """
    try:
        logging.info('------------------->Thread URL: ' + t_url)
        thread_url = t_url
        soup = t_module.get_parse_content(t_url)
        meta_dic = yaml_obj.get(forum).get('Meta')
        post_dic = yaml_obj.get(forum).get('Meta').get('Post')
        if soup:
            # Get all thread list pages by pagination
            total_pages = t_module.get_total_page_count (soup, t_url)
            print "total Thread Pages", total_pages
            for page in range(1, total_pages + 1):
                _session = sessionmaker()
                _session.configure(bind=engine)

                # create session
                session = _session()

                post_list = list()

                # Form a Thred URL
                thread_url = baseurl + (str(meta_dic.get('Thread').get('page_url')) % (t_id, page))
                print thread_url
                soup = t_module.get_parse_content(thread_url)
                if not soup:
                    failed_post_list.append(thread_url)
                    continue
                rows = t_module.get_post_rows(soup)
                for row in rows:
                    post_info = t_module.get_post_info (row)
                    if post_info:
                        post_date = post_info['post_date']
                        post_body = post_info['post_body']
                        member_name = post_info['member_name']
                        post_id = post_info['post_id']
                    else:
                        continue

                    # Check for exisiting entry in the DB.
                    # If entry is not present then add it to DB.

                    is_post_details_exist = session.query(
                        Post
                    ).filter_by(third_party_id=post_id,
                                thread_uuid=thread_uuid).first()

                    if not is_post_details_exist:
                        post_uuid = str(uuid.uuid4())
                        logging.info('******** Thread URL: \t' + str(thread_url))
                        logging.info('******** Thread Id: \t' + str(t_id))
                        logging.info('******** Thread UUID: \t' + str(thread_uuid))
                        logging.info('******** Member Name: \t' + str(member_name))
                        logging.info('******** Post UUID: \t' + str(post_uuid))
                        logging.info('******** Post Body: \t' + str(post_body))
                        logging.info('******** Posted Date\t' + str(post_date))

                        print('******** Thread URL: ', str(thread_url))
                        print('******** Thread Id: ', str(t_id))
                        print('******** Member Name: ', str(member_name))
                        print('******** Post Body: ', str(post_body))
                        print('******** Posted Date', str(post_date))

                        # Add data to database
                        post = Post(uuid=post_uuid, thread_uuid=thread_uuid,
                                    third_party_id=post_id,
                                    member_name=member_name,
                                    body=post_body, created_at=post_date)
                        post_list.append(post)

                session.bulk_save_objects(post_list)
                session.flush()
                session.commit()
                session.close()
        else:
            failed_post_list.append(thread_url)
            print "****************************************** Thread Page Not Found ***************************"
    except Exception as e:
        print '************** thread_url exception :\t' + str(thread_url)
        failed_post_list.append(thread_url)
        print "************** Thread Exception *****************"
        print e
        pass


def dowork(q):
    while True:
        try:
            url = q.get()
            logging.info('******************* current url:\t' + url)
            parse_thread(url)
            q.task_done()
        except Exception as e:
            logging.info('******************* ERROR Dowork ************')
            logging.info('******************* url:\t' + url)
            logging.info('******************* Exception:\t' + str(e))
            q.task_done()


if __name__ == '__main__':

    try:
        starttime = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

        print "Initializing Threads"
        for i in range(1, yaml_obj[forum]['NUM_THREADS']):
            worker = Thread(target=dowork, args=(q,))
            worker.setDaemon(True)
            worker.start()

        # Start scraping the forum
        print "Start Forum Scraping"
        parse_forum()

        q.join()
        time.sleep(1)
        print "Sucessfully completed!"
        logging.info('************** Sucessfully completed! ******** ')

        endtime = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        logging.info("Failed Threads")
        logging.info(failed_thread_list)
        print failed_thread_list

        logging.info("Failed Posts:")
        logging.info(failed_post_list)
        print failed_post_list

        logging.info('******** start time:\t' + starttime)
        logging.info('******** end time:\t' + endtime)
        sys.exit()
    except KeyboardInterrupt:
        # quit
        print "Failed Threads"
        print failed_thread_list
        print "-----------------------------------------------------------"
        print "Failed Posts"
        print failed_post_list
        sys.exit()
