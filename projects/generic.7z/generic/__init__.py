import re
import os
import sys
import urlparse
import uuid
import logging
import threading
import time
import mechanize
import cookielib
import yaml
import argparse
import importlib
import generic_initialize_db
import dateutil.parser as dparser #to get date from a string, multiple strings ,today,tomorrow

from bs4 import BeautifulSoup
from datetime import datetime
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from models import Topic, Post
from sqlalchemy.exc import IntegrityError
from Queue import Queue
from threading import Thread
from dateparser import parse


with open(r'settings.yaml', 'r') as stream:
    try:
        yaml_obj = yaml.load(stream)
    except yaml.YAMLError as exc:
        print(exc)
        raise
        
# Initialize browser.
cj = cookielib.CookieJar()
browser = mechanize.Browser()
browser.set_handle_robots(False)
browser.addheaders = [('User-agent', 'Mozilla/5.0 (X11; U; Linux i686; en-US; rv:1.9.0.1) Gecko/2008071615 Fedora/3.0.1-1.fc9 Firefox/3.0.1')]
browser.set_cookiejar(cj)