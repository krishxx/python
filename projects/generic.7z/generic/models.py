from sqlalchemy.ext.declarative import declarative_base

from sqlalchemy import Column, DateTime, Integer, CHAR, VARCHAR
from sqlalchemy.dialects.mysql import LONGTEXT

Base = declarative_base()


class Topic(Base):
    """
    CREATE TABLE `threads` (
        `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
        `uuid` char(36) CHARACTER SET latin1 NOT NULL,
        `forum_uuid` char(36) NOT NULL DEFAULT '',
        `third_party_id` varchar(64) CHARACTER SET latin1 NOT NULL DEFAULT '',
        `name` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
        `created_at` datetime NOT NULL,
        `url` varchar(255) CHARACTER SET latin1 NOT NULL DEFAULT '',
        PRIMARY KEY (`id`),
        UNIQUE KEY `unique_url` (`url`),
        UNIQUE KEY `unique_uuid` (`uuid`),
        UNIQUE KEY `unique_forum_thread` (`forum_uuid`,`third_party_id`)
    ) ENGINE=InnoDB AUTO_INCREMENT=0 DEFAULT CHARSET=utf8;
    """

    __tablename__ = 'threads'
    tid = Column('id', Integer, primary_key=True, autoincrement=True)
    uuid = Column('uuid', CHAR(36), unique=True, nullable=False)
    forum_uuid = Column('forum_uuid', CHAR(36), nullable=False, default='')
    third_party_id = Column(
        'third_party_id', VARCHAR(64), nullable=False, default='')
    name = Column('name', VARCHAR(255, collation='utf8_unicode_ci'),
                  nullable=False, default='')
    created_at = Column('created_at', DateTime, nullable=False)
    url = Column(
        'url', VARCHAR(255, collation='utf8_unicode_ci'), nullable=False, default='')

    def __init__(self, uuid, forum_uuid,
                 third_party_id, name, created_at, url):
        self.uuid = uuid
        self.forum_uuid = forum_uuid
        self.third_party_id = third_party_id
        self.name = name
        self.created_at = created_at
        self.url = url

    def __repr__(self):

        return "<Metadata('%s','%s','%s','%s','%s','%s','%s')>" % (
            self.tid, self.uuid, self.forum_uuid,
            self.third_party_id, self.name, self.created_at, self.url)


class Post(Base):
    """
    CREATE TABLE `posts` (
        `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
        `uuid` char(36) NOT NULL DEFAULT '',
        `thread_uuid` char(36) CHARACTER SET latin1 NOT NULL DEFAULT '',
        `third_party_id` varchar(64) CHARACTER SET latin1 DEFAULT NULL,
        `member_name` varchar(64) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
        `body` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
        `created_at` datetime NOT NULL,
        PRIMARY KEY (`id`),
        UNIQUE KEY `unique_uuid` (`uuid`),
        UNIQUE KEY `unique_thread_post` (`thread_uuid`,`third_party_id`)
    ) ENGINE=InnoDB AUTO_INCREMENT=0 DEFAULT CHARSET=utf8;
    """

    __tablename__ = 'posts'

    pid = Column('id', Integer, primary_key=True, autoincrement=True)
    uuid = Column('uuid', CHAR(36), unique=True, nullable=False)
    thread_uuid = Column('thread_uuid', CHAR(36), nullable=False)
    third_party_id = Column('third_party_id', VARCHAR(64), default=None)
    member_name = Column(
        'member_name', VARCHAR(255, collation='utf8_unicode_ci'),
        nullable=False, default='')
    body = Column(
        'body', LONGTEXT(collation='utf8_unicode_ci'), nullable=False)
    created_at = Column('created_at', DateTime, nullable=False)

    def __init__(self, uuid, thread_uuid,
                 third_party_id, member_name, body, created_at):
        self.uuid = uuid
        self.thread_uuid = thread_uuid
        self.third_party_id = third_party_id
        self.member_name = member_name
        self.body = body
        self.created_at = created_at

    def __repr__(self):

        return "<Metadata('%s','%s','%s','%s','%s','%s','%s')>" % (
            self.pid, self.uuid, self.thread_uuid, self.third_party_id,
            self.member_name, self.body, self.created_at)
