from generic.core import *


# Scrapping the data by url
def get_parse_content(url):
    """ Get scrape content by url """
    count = 2
    try:
        content = browser.open(url).read()

        # Beautiful Soup is a Python library for pulling data out of HTML files
        return BeautifulSoup(content, 'html.parser')

    except Exception:
        return None

def get_forum_urls (soup):
    r_url = yaml_obj.get(forum).get('Meta').get('Forum').get('url')

    if r_url == None:
        raise 'IN YAML File required field is not found'
    r_url = yaml_obj.get(forum).get('Meta').get('Forum').get('url')
    return re.findall (re.escape(r_url).replace('\%s', '[\d]+'), str(soup), re.I)


def get_total_page_count (soup, url):
    '''
        Get given url pages count by pagination
    '''
    try:
        total_pages = 1
        pagenav_dic = yaml_obj.get(forum).get('Meta').get('Thread').get('soup').get('pagenav')
        pagenav = soup.find(pagenav_dic.get('tag'), {'class': pagenav_dic.get('class')})
        if pagenav:
            pagenav_dic = yaml_obj.get(forum).get('Meta').get('Thread').get('find').get('pagenav')
            total_pages = pagenav.find(pagenav_dic.get('tag'), {'class': pagenav_dic.get('class')})
            if total_pages:
                total_pages = total_pages.text.strip()
            else:
                total_pages = '1'
            if total_pages:
                total_pages = int(total_pages.split(' ')[-1])
            else:
                total_pages = 1
    except Exception as e:
        total_pages = 1
        print "+++++++++++++++++++++++++++++++++", e, "+++++++++++++++++++++++++++++++"
        print "$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$", url
    return total_pages

#TO check provided string has valid date or not
def is_date(string):
	try: 
		parse(string)
		return True
	except ValueError:
		return False

#To get Required format of provided date
def get_utc(givendate):
	try: 
		parsed_Date = parse(givendate, settings={'TO_TIMEZONE': 'UTC','RETURN_AS_TIMEZONE_AWARE': False })
		if parsed_Date == None: # If date string has combination of strings and date
			try:
				parsed_Date = dparser.parse(givendate,fuzzy=True)
				
			except ValueError:
				parsed_Date = datetime.utcnow()
				
		return parsed_Date
	except ValueError:
		return datetime.utcnow()

def get_thread_rows (soup, f_id):
    tbody_dic = yaml_obj.get(forum).get('Meta').get('Thread').get('soup').get('seperator')
    tbody = soup.find(tbody_dic.get('tag'), id=tbody_dic.get('id') % (f_id))
    meta_dic = yaml_obj.get(forum).get('Meta')
    rows = tbody.findAll(meta_dic.get('Thread').get('find').get('seperator').get('tag')) if         tbody else []
    return rows
    
def get_thread_info (row, baseurl):
    meta_dic = yaml_obj.get(forum).get('Meta')
    thread_name = ''
    thread_date = None
    thread_info = row.find(meta_dic.get('Thread').get('find').get('info').get('tag'), id=re.compile(meta_dic.get('Thread').get('find').get('info').get('id')))
    if not thread_info:
        return None
    thread_title = thread_info.find(meta_dic.get('Thread').get('find').get('title').get('tag'), id=re.compile(meta_dic.get('Thread').get('find').get('title').get('id')))
    if thread_title:
        thread_name = thread_title.text.encode('utf-8')
        thread_url = thread_title.get('href')
        thread_url = baseurl + '' + thread_url
        thread_id = thread_title.get('id').replace(meta_dic.get('Thread').get('find').get('title').get('id'), "")

        # if thread_id != thread_url.rsplit('=', 1)[-1]:
        if thread_id not in thread_url:
            return None

        thread_obj = row.find(meta_dic.get('Thread').get('find').get('date').get('tag'), {"class": meta_dic.get('Thread').get('find').get('date').get('class')})
        threaddate = thread_obj.text.encode('utf-8').strip()
        #print datetime.utcnow()
        if is_date(threaddate):
            print "BEFORE ::",threaddate
            thread_date = get_utc(threaddate)
            if thread_date > datetime.utcnow():
                thread_date = datetime.utcnow()
            print "AFTER ::",thread_date
            
        else:
            thread_date = datetime.utcnow()
    else:
        return None
        
    return {'thread_date' : thread_date, 'thread_name' : thread_name, 'thread_url': thread_url}
    
def get_post_rows (soup):
    post_dic = yaml_obj.get(forum).get('Meta').get('Post')
    rows = soup.findAll(post_dic.get('soup').get('seperator').get('tag'), id=re.compile(post_dic.get('soup').get('seperator').get('id')))
    return rows

def get_post_info (row):
    post_id = None
    member_name = ''
    post_date = None
    post_body = ''
    post_dic = yaml_obj.get(forum).get('Meta').get('Post')
    post_id = row.get('id').replace('post', '')
    post_member = row.find(post_dic.get('find').get('member').get('tag'), {"class": post_dic.get('find').get('member').get('class')})
    member_name = post_member.text.encode('utf-8').strip()
    post_message = soup.find(post_dic.get('find').get('message').get('tag') , id=re.compile(post_dic.get('find').get('message').get('id') % (post_id)))
    if post_message:
        post_body = post_message.text.strip().encode('utf-8')
    post_date = row.find(post_dic.get('find').get('date').get('tag') , class_= post_dic.get('find').get('date').get('class'))
    
    # print post_date
    if post_date:
        post_date = post_date.text.strip().encode('utf-8')
        if is_date(post_date):
            print "BEFORE ::",post_date
            post_date = get_utc(post_date)
            if post_date > datetime.utcnow():
                post_date = datetime.utcnow()
            print "AFTER ::",post_date
    else:
        post_date = datetime.utcnow()
    
    return {'post_date' : post_date, 'post_body' : post_body, 'member_name': member_name, 'post_id': post_id}