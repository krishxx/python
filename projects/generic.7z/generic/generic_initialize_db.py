#!/usr/bin/python

import MySQLdb
import yaml

def initialize_db (forum, rawhtml=False):
    with open(r'settings.yaml', 'r') as stream:
        try:
            yaml_obj = yaml.load(stream)
        except yaml.YAMLError as exc:
            print(exc)
            raise

    # Open database connection
    db = MySQLdb.connect(yaml_obj[forum]['HOST'], yaml_obj[forum]['DB_USERNAME'], yaml_obj[forum]['DB_PASSWORD'])

    # prepare a cursor object using cursor() method
    cursor = db.cursor()

    # Create database if not exists, using execute() method.
    cursor.execute("CREATE DATABASE IF NOT EXISTS " + yaml_obj[forum]['DB_NAME'])

    # disconnect from server
    db.close()
    print "---------------------------------------------------------------"
    print "%s DB Initialization is Successful." %forum

    if rawhtml:
        from raw_models import RawData as Base
    else:
        from models import Base

    from sqlalchemy import create_engine
    DB_URL = 'mysql://' + yaml_obj[forum]['DB_USERNAME'] + ':' + yaml_obj[forum]['DB_PASSWORD'] + '@' + yaml_obj[forum]['HOST'] + '/' + yaml_obj[forum]['DB_NAME'] + '?charset=utf8'
    engine = create_engine(DB_URL)

    # Create all tables
    Base.metadata.create_all(engine)

